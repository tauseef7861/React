
import * as firebase from 'firebase';
var config = {
    apiKey: "AIzaSyCUuYzqGOdxBwHvQmZm-e0pgvkrRFg8NNc",
    authDomain: "mynotesapp-7861.firebaseapp.com",
    databaseURL: "https://mynotesapp-7861.firebaseio.com",
    projectId: "mynotesapp-7861",
    storageBucket: "mynotesapp-7861.appspot.com",
    messagingSenderId: "64492176011"
  };
  firebase.initializeApp(config);
const googleAuthProvider = new firebase.auth.GoogleAuthProvider();

export {firebase, googleAuthProvider} ;


