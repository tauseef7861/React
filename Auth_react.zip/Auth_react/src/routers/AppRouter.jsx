import React, { Component ,Fragment} from 'react';
import { Router, Route, Switch , Redirect } from 'react-router-dom';
import NotesApp from '../components/NotesApp';
import EditNote from '../components/EditNote';
import WelcomePage from '../components/WelcomePage';
import { cyan } from '@material-ui/core/colors';
import { createMuiTheme, MuiThemeProvider } from '@material-ui/core/styles';
import createHistory from 'history/createBrowserHistory';
import Header from '../components/Header';


export const history = createHistory();

const theme = createMuiTheme({
    palette: {
        primary: cyan,        
    },
    typography: {
        useNextVariants: true,
    },
});


function PrivateRoute({ component: Component,  ...rest }) {
    return (
      <Route
        {...rest}
        render={props =>
            (localStorage.getItem('isLoggedIn') || false) ? (
            <MuiThemeProvider theme={theme}>
                <Component  
                {...rest}
                {...props} />
            </MuiThemeProvider>
          ) : (
            <Redirect
              to={{
                pathname: "/",
                state: { from: props.location }
              }}
            />
          )
        }
      />
    );
  }

class AppRouter extends Component {
    constructor(props) {
        super(props);
        this.state = {
            notes: [],
        };
        this.handleAddNote = this.handleAddNote.bind(this);
        this.handleRemoveNote = this.handleRemoveNote.bind(this);
        this.handleUpdateNote = this.handleUpdateNote.bind(this);
    }

    componendDidMount() {
        // Get all the notes
    }

    handleAddNote(note) {
        this.setState((currState) => ({
            notes: currState.notes.concat([note])
        }));

        // Post a new note
    }

    handleRemoveNote(noteId) {
        const noteIndexToRemove = this.state.notes.findIndex(note => note.id === noteId);  
        this.setState((currState) => ({
            notes: [...currState.notes.slice(0, noteIndexToRemove), ...currState.notes.slice(noteIndexToRemove + 1)]
        }));

        // Delete the note
    }

    handleUpdateNote(updatedNote) {
        const noteIndexToUpdate = this.state.notes.findIndex(note => note.id === updatedNote.id);  
        this.setState((currState) => ({
            notes: [...currState.notes.slice(0, noteIndexToUpdate), {...updatedNote}, ...currState.notes.slice(noteIndexToUpdate + 1)]
        }));

        // Update the note
    }

    render() {
        return (
            <Fragment>
                <MuiThemeProvider theme={theme}>
                    <Header />
                </MuiThemeProvider>
                <Router history={history}>
                    <Switch>
                        <Route
                            path="/"
                            exact
                            render={()=>(
                                <MuiThemeProvider theme={theme}>
                                    <WelcomePage/>
                                </MuiThemeProvider>
                            )}                          
                        />
                        <PrivateRoute 
                            path="/home" 
                            exact                            
                            component ={NotesApp}                                                                   
                            notes={this.state.notes}
                            handleAddNote={this.handleAddNote}
                            handleRemoveNote={this.handleRemoveNote}                                                         
                        />
                        <PrivateRoute 
                            path="/edit-note/:id" 
                            component={EditNote}
                            notes={this.state.notes}
                            handleUpdateNote={this.handleUpdateNote}                            
                        />
                    </Switch>
                </Router>
            </Fragment>
        );
    }
}

export default AppRouter;