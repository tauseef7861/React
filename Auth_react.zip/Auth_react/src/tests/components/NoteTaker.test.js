import React from 'react';
import { shallow, mount} from 'enzyme';
import NoteTaker from '../../components/NoteTaker';
import { createSerializer } from 'enzyme-to-json';



expect.addSnapshotSerializer(createSerializer({mode: 'deep'}));

let wrapper, handleAddNote, noteArr;
beforeEach( () => {
    noteArr = [
        {
            "noteTitle":"myNote",
            "noteDescription":"mydesc-3",
            "id":3
        }
        
    ]
    handleAddNote = jest.fn();
    wrapper = shallow(
        <NoteTaker notes = {noteArr} handleAddNote = {handleAddNote} />
    );
});

test('NoteTaker component should render correctly', () => {
    expect(wrapper).toMatchSnapshot();
})