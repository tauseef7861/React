import React from 'react';
import NotesContainer from '../../components/NotesContainer';
import { shallow, mount} from 'enzyme';
import { createSerializer } from 'enzyme-to-json';


let wrapper, handleRemoveNote, noteArr;

beforeEach( () => {
    noteArr = [
        {
            "noteTitle" : "mynote-4",
            "noteDescription" : "myDesc-4",
            "id" : 4
        }
    ]
    handleRemoveNote = jest.fn();
    wrapper = shallow(
        <NotesContainer notes = {noteArr} handleRemoveNote = {handleRemoveNote} />
    );
});

test('NotesContainer should render Correctly', () => {
    expect(wrapper).toMatchSnapshot();
});