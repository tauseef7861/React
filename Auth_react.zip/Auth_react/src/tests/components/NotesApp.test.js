import React from 'react';
import { shallow, mount} from 'enzyme';
import { createSerializer } from 'enzyme-to-json';
import NotesApp from '../../components/NotesApp';
expect.addSnapshotSerializer(createSerializer({mode: 'deep'}));

let wrapper, noteArr, handleAddNote, handleRemoveNote;

beforeEach( () => {
    noteArr = [
        {
            "noteTitle":"Mytitle-1",
            "noteDescription":"myDesc-1",
            "id":2
        }
    ]
    handleAddNote = jest.fn();
    handleRemoveNote = jest.fn();
    wrapper = shallow(
        <NotesApp notes = {noteArr} handleAddNote = {handleAddNote} handleRemoveNote = {handleRemoveNote} />
    );
});

test('Notes App should render correctly', () => {
    expect(wrapper).toMatchSnapshot();
});