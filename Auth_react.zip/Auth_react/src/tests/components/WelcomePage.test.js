import React from 'react';
import WelcomePage from '../../components/WelcomePage';
import {shallow, mount} from 'enzyme';
import { createSerializer } from 'enzyme-to-json';

expect.addSnapshotSerializer(createSerializer({mode: 'deep'}));


test('WelcomePage shoud render correctly',() =>{
    const wrapper = shallow(<WelcomePage />);
    expect(wrapper).toMatchSnapshot();
})