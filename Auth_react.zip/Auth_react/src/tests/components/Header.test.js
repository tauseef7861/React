import {shallow, mount } from 'enzyme';
import Header from '../../components/Header';
import React from 'react';
import { createSerializer } from 'enzyme-to-json';


expect.addSnapshotSerializer(createSerializer({
    mode: 'deep'}));

    test('Header component should render correctly',() => {
        const wrapper = mount(<Header />);
        expect(wrapper).toMatchSnapshot();
    })