import React from 'react';
import { shallow, mount } from 'enzyme';
import { createSerializer } from 'enzyme-to-json';
import Note from '../../components/Note';

expect.addSnapshotSerializer(createSerializer({mode: 'deep'}));

let wrapper, noteArr, handleRemoveNote;
beforeEach( () => {
    noteArr = [
        {
            "noteTitle" : "Title-1",
            "noteDescription" : "Desc-1",
            "id" : 1
        }
    ]
    handleRemoveNote = jest.fn();
    wrapper = shallow(
        <Note note = {noteArr} handleRemoveNote= {handleRemoveNote} />
    );
});

test('Note component should render correctly', () => {
    expect(wrapper).toMatchSnapshot();
});