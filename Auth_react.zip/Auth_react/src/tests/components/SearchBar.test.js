import React from 'react';
import {shallow, mount} from 'enzyme';
import { createSerializer} from 'enzyme-to-json';
import SearchBar from '../../components/SearchBar';

expect.addSnapshotSerializer(createSerializer({
    mode: 'deep'}));

test('SearchBar component should render correctly',() =>{
    const wrapper = shallow(<SearchBar />);
    expect(wrapper).toMatchSnapshot();
});