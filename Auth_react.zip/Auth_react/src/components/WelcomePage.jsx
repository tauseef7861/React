import React, { Fragment } from 'react';
import { MDBCarousel, MDBCarouselInner, MDBCarouselItem, MDBView, MDBMask, MDBContainer, MDBJumbotron } from "mdbreact";

import note1 from '../images/note-1.jpeg';
import note2 from '../images/note-2.jpeg';
import note3 from '../images/note-3.jpeg';


function WelcomePage(props) {
    return (
        <Fragment>
            <MDBContainer>
                <MDBCarousel activeItem={1} length={3} showControls={true} showIndicators={true} className="z-depth-1">
                    <MDBCarouselInner>
                        <MDBCarouselItem itemId="1">
                            <MDBView>
                                <img className="d-block w-100" src={note1} alt="First slide" />                                
                                <MDBMask overlay="black-light" />
                            </MDBView>
                        </MDBCarouselItem>
                        <MDBCarouselItem itemId="2">
                            <MDBView>
                                <img className="d-block w-100" src={note2} alt="Second slide" />
                                <MDBMask overlay="black-strong" />
                            </MDBView>
                        </MDBCarouselItem>
                        <MDBCarouselItem itemId="3">
                            <MDBView>
                                <img className="d-block w-100" src={note3} alt="Third slide" />
                                <MDBMask overlay="black-slight" />
                            </MDBView>
                        </MDBCarouselItem>                       
                    </MDBCarouselInner>
                </MDBCarousel>
            </MDBContainer>

            <MDBJumbotron fluid>
                <MDBContainer>
                    <h1 className="display-4" >Take The Notes and Never Forget Anything!!</h1>
                    <p className="lead">One of the best app for managing all your notes and todos at one place, so that you never miss anything important in your life.</p>
                </MDBContainer>
            </MDBJumbotron>
           
        </Fragment>
    );


};

export default WelcomePage;