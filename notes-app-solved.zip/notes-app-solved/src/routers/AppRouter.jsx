import React, { Component } from 'react';
import { BrowserRouter, Route, Switch } from 'react-router-dom';
import NotesApp from '../components/NotesApp';
import EditNote from '../components/EditNote';

class AppRouter extends Component {
    constructor(props) {
        super(props);
        this.state = {
            notes: [],
            t_notes:[],
        };
        this.handleAddNote = this.handleAddNote.bind(this);
        this.handleRemoveNote = this.handleRemoveNote.bind(this);
        this.handleUpdateNote = this.handleUpdateNote.bind(this);
    }

    componendDidMount() {
        // Get all the notes
        console.log("componentDidMount");
        // Get all the notes
        fetch('http://localhost:8080/notes')
            .then(response => response.json())
            .then(notes => {               
                this.setState({
                    notes: notes,
                    t_notes:notes,                    
                });
            });
    }

    handleAddNote(note) {
        const newNote = {
            id: Math.floor((Math.random() * 100) + 10),            
            title: note.title,
            description: note.description
        };
        this.setState((currState) => ({
            notes: currState.notes.concat([newNote])
        }));

        fetch('http://localhost:8080/notes', {
            method: 'POST',
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify(note)
        })
        .then(response => response.json())
        .then(note => console.log(`note created with value: ${JSON.stringify(note)}`));
    }

    handleRemoveNote(noteId) {
        const noteIndexToRemove = this.state.notes.findIndex(note => note.id === noteId);  
        this.setState((currState) => ({
            notes: [...currState.notes.slice(0, noteIndexToRemove), ...currState.notes.slice(noteIndexToRemove + 1)]
        }));

        // Delete the note
    }

    handleUpdateNote(updatedNote) {
        const noteIndexToUpdate = this.state.notes.findIndex(note => note.id === updatedNote.id);  
        this.setState((currState) => ({
            notes: [...currState.notes.slice(0, noteIndexToUpdate), {...updatedNote}, ...currState.notes.slice(noteIndexToUpdate + 1)]
        }));

        // Update the note
    }

    render() {
        return (
            <BrowserRouter>
                <Switch>
                    <Route 
                        path="/home" 
                        render={(props) => (<NotesApp
                                                {...props}
                                                notes={this.state.notes}
                                                handleAddNote={this.handleAddNote}
                                                handleRemoveNote={this.handleRemoveNote}
                                            />)}
                        exact 
                    />
                    <Route 
                        path="/edit-note/:id" 
                        render={(props) => <EditNote
                                                {...props}
                                                notes={this.state.notes}
                                                handleUpdateNote={this.handleUpdateNote} 
                                            />} 
                    />
                </Switch>
            </BrowserRouter>
        );
    }
}

export default AppRouter;