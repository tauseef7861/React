import React from 'react';

import NoteTaker from './NoteTaker';
import GridView from './GridView';
import ListView from './ListView';


class NotesContainer extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            notes: [],
            newNotes:[],                     
        }
        this.handleOnSubmit = this.handleOnSubmit.bind(this);
        this.handleRemove = this.handleRemove.bind(this);   
        this.handleSearchTextEvent = this.handleSearchTextEvent.bind(this);  
        this.handleUpdateNote = this.handleUpdateNote.bind(this);         
    }

    componentDidMount() {
       fetch('http://localhost:8080/notes')
            .then(response => response.json())
            .then(notes => {               
                this.setState({
                    notes: notes,
                    newNotes:notes,                    
                });
            });
    }    


    handleOnSubmit(title, description) {        
        const newNote = {
            id: Math.floor((Math.random() * 100) + 10), 
            title: title,
            description: description
        };
        this.setState((currState) => ({
            notes: currState.notes.concat(newNote)
        }));
        fetch('http://localhost:8080/notes', {
            method: 'POST',
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify(newNote)
        })
        .then(response => response.json())
        .then(note => console.log(`note created with value: ${JSON.stringify(note)}`));
    }

    handleRemove(id){
        
        fetch('http://localhost:8080/notes/'+id, {
            method: 'DELETE',
            headers: {"Content-Type": "application/json"}            
        })
        .then(response => response.json())
        .then(
            console.log("delete "+id)           
        );
        const data = this.state.notes.filter(i=>i.id !== id);
        this.setState((currState) => ({
            notes : data,
            newNotes: data,
        }));
    }
    
    
    handleUpdateNote(updatedNote) {
        const noteIndexToUpdate = this.state.notes.findIndex(note => note.id === updatedNote.id); 
        
        fetch('http://localhost:8080/notes/'+updatedNote.id, {
            method: 'PUT',
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify(updatedNote)
        })        
        .then(response => response.json())
        .then(note => console.log(`note created with value: ${JSON.stringify(note)}`));        

        this.setState((currState) => ({
            notes: [...currState.notes.slice(0, noteIndexToUpdate), {...updatedNote}, ...currState.notes.slice(noteIndexToUpdate + 1)]
        }));   
    }

    handleSearchTextEvent(searchText){        
        console.log("notes container searchText:===> "+searchText);   
        if(!searchText || '' === searchText){
            this.setState({
                notes: this.state.newNotes,                                
            });
        }else if(searchText.length > 3){
            let searchNoteArray=this.state.newNotes;
            const data = searchNoteArray.filter(note=>note.title.startsWith(searchText));
            this.setState({
                notes: data                    
            });
        }
    }

    render() {                
        return (
            <React.Fragment>
                     <NoteTaker handleOnSubmit={this.handleOnSubmit}/> 
                    {
                        ((this.props.notesView  === 'Grid')? 
                          <GridView notes={this.state.notes} handleRemove={this.handleRemove} handleUpdateNote = {this.handleUpdateNote}/> 
                        : <ListView notes={this.state.notes} handleRemove={this.handleRemove} handleUpdateNote = {this.handleUpdateNote} />)
                    }                               
            </React.Fragment>
        );
    }      
}

export default NotesContainer;
