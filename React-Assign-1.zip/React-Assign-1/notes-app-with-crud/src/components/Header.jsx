import React from 'react';
import PropTypes from 'prop-types';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
import { withStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import SearchBar from './SearchBar';

const styles = theme => ({
  root: {
    width: '100%',
  },
  menuButton: {
    marginLeft: -12,
    marginRight: 20,
  },
  title: {
    display: 'flex',
    [theme.breakpoints.up('sm')]: {
      display: 'block',
    },
  },
});

class Header extends React.Component{
    constructor(props){
      super(props);
      this.state={
        view: 'List'
      };
      this.handleViewChange =this.handleViewChange.bind(this);
      this.handleSearchText = this.handleSearchText.bind(this);
    }

    handleSearchText(searchText){
     ;
      this.props.handleSearchText(searchText);
    }

    handleViewChange(e){
      console.log(this.state.view);
      if(this.state.view === 'Grid') {
        this.setState({
          view: 'List'
        });      
      }else{
        this.setState({
          view: 'Grid'
        });      
      }  
      this.props.handleViewChange(this.state.view);
    }


   render(){
    const { classes } = this.props;
     return(
      <div className={classes.root}>
      <AppBar position="static">
       <Toolbar>
          <Typography className={classes.title} variant="h6" color="inherit" noWrap>
            Note-Keeper-App
          </Typography>
          <SearchBar handleSearchText={this.handleSearchText}/>
          <Button variant="contained" color="secondary" className={classes.button} onClick={this.handleViewChange}>{this.state.view} </Button>
        </Toolbar>
      </AppBar>
    </div>
     );
   }
}

Header.propTypes = {
  classes: PropTypes.object.isRequired,
};

export default withStyles(styles)(Header);    // HOC -> Higher Order Component which takes another compoennt as an argument
