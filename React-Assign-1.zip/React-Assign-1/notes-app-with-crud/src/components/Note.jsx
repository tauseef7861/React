import React from 'react';
import Card from '@material-ui/core/Card';
import Typography from '@material-ui/core/Typography';
import { withStyles } from '@material-ui/core/styles';
import DeleteIcon from '@material-ui/icons/Delete';
import CardContent from '@material-ui/core/CardContent';
import CardActions from '@material-ui/core/CardActions';
import EditIcon from '@material-ui/icons/Edit';
import EditNote from './EditNote';
import CardHeader from '@material-ui/core/CardHeader';
import IconButton from '@material-ui/core/IconButton';




const styles = theme =>({
     card: {
        margin: 5,
        padding: 10,
        minWidth: 100,
        cellHeight:'auto',
    },
    icon: {
        color: 'red',
        marginLeft: 'auto',
        margin: theme.spacing.unit*2,
        fontSize: 20,
    
    },
     actions: {
        display: 'block',
        margin: 'auto',
    }, 
    
    typography: {
        useNextVariants: true,
    },

});


class Note extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            open: false     
        }
        this.handleClickOpen=this.handleClickOpen.bind(this);
        this.handleClickCancel=this.handleClickCancel.bind(this);
    }
    
    handleClickOpen() {
        this.setState({ open: true });
    }

    handleClickCancel() {
        this.setState({ open: false });
    }

    render(){
        const { classes } = this.props;
        return (
            <React.Fragment>
                {
                    (this.state.open)  ?    
                        
                        <EditNote id={this.props.id} title={this.props.title} description={this.props.content} handleUpdateNote={this.props.handleUpdateNote} handleClickCancel={this.handleClickCancel}/>:
                
                        <Card className={classes.card} >
                            <CardHeader title={this.props.title} 
                                        action={  
                                            <IconButton onClick={this.handleClickOpen}>
                                                <EditIcon />
                                               
                                            </IconButton>
                                            }
                            />                                 
                            <CardContent>                    
                                <Typography component="p">{this.props.content}</Typography>
                            </CardContent>
                            <CardActions className={classes.actions}>
                                <DeleteIcon className={classes.icon} onClick={this.props.handleRemove.bind(null, this.props.id)} />                     
                            </CardActions>
                           
                        </Card>
                
                }
            </React.Fragment>                     
        );
    }
};

export default withStyles(styles)(Note);
