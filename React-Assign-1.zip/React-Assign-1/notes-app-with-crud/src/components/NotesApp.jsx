import React, { Component, Fragment } from 'react';
import Header from './Header';
import NotesContainer from './NotesContainer';
import { cyan } from '@material-ui/core/colors';
import { createMuiTheme, MuiThemeProvider } from '@material-ui/core/styles';

const theme = createMuiTheme({
    palette: {
        primary: cyan,
        contrastThreshold:4,
          
        },
    typography: {
        useNextVariants: true,
    },
});

class NotesApp extends Component {
    constructor(props) {
        super(props);
        this.state = {           
            htitle: 'My Notes',
            notes_view: 'Grid',
            searchText :''
        }
        this.handleViewChange =this.handleViewChange.bind(this); 
        this.handleSearchText = this.handleSearchText.bind(this);               
    }

    handleViewChange(value){
      
        this.setState({
            notes_view: value
        })
    }

    handleSearchText(searchText){
        this.setState({
            searchText: searchText
        })
        this.refs.notesContainer.handleSearchTextEvent(searchText);
      }


    render() {
        return (
            <MuiThemeProvider theme={theme}>
            
            <Fragment>
                <Header htitle={this.state.htitle} handleViewChange={this.handleViewChange} handleSearchText={this.handleSearchText}/>
                <NotesContainer notesView={this.state.notes_view} searchText={this.state.searchText} ref="notesContainer"/>                
            </Fragment>
           
            </MuiThemeProvider>
        );
    }
}

export default NotesApp;