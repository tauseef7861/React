import React from 'react';
import { withStyles } from '@material-ui/core/styles';
import Note from './Note';

const styles = theme => ({
    noteTaker:{
      display: 'flex',
      flexWrap: 'wrap',
      justifyContent: 'space-around',
      overflow: 'hidden',
    },
  
  });


class ListView extends React.Component {

    render() {
        const { classes } = this.props;
        return (
            <div className={classes.noteTaker}>
               <div id="listViews">
               {this.props.notes.map(note => <Note key={note.id} 
                                                        id={note.id} 
                                                        title={note.title} 
                                                        content={note.description} 
                                                        handleRemove={this.props.handleRemove}                                                            
                                                        handleUpdateNote={this.props.handleUpdateNote}
                                                        />)}
              </div>
            </div>
        ); 
    }

}

export default withStyles(styles)(ListView);