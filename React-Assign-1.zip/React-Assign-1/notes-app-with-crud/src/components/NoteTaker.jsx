import React from 'react';
import { withStyles } from '@material-ui/core/styles';
import Paper from '@material-ui/core/Paper';
import Typography from '@material-ui/core/Typography';
import Button from '@material-ui/core/Button';
import TextField from '@material-ui/core/TextField';


const styles = theme => ({
  root: {
    paddingLeft: theme.spacing.unit * 2,
    paddingBottom: theme.spacing.unit * 2,
    margin: theme.spacing.unit*2,
    display:'inline-block',
  },
  noteTaker:{
    display: 'flex',
    flexWrap: 'wrap',
    justifyContent: 'space-around',
    overflow: 'hidden',
    minWidth :theme.spacing.unit*10,
  },

});

class NoteTaker extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            n_title: '',
            n_description:''
        };
        this.handleTitleChange = this.handleTitleChange.bind(this);
        this.handleDescChange = this.handleDescChange.bind(this);
        this.handleOnSubmit= this.handleOnSubmit.bind(this);
    }

    handleTitleChange(event) {
      this.setState({
            n_title: event.target.value
        });                
    }

    handleDescChange(event) {
        this.setState({
            n_description: event.target.value
        });                
    }
    
    handleOnSubmit(e) {
         e.preventDefault();        
        this.props.handleOnSubmit(this.state.n_title, this.state.n_description);
        this.setState({
            n_title: '',
            n_description:''
        })
    }

    render() {
        const { classes } = this.props;

        return (
            <div className={classes.noteTaker}>
              <Paper className={classes.root} elevation={2}>
                <form onSubmit={this.handleOnSubmit} className={classes.container} noValidate autoComplete="off">
                    <Typography  variant="h5" component="div" align='left'>
                        <TextField
                            id="standard-with-placeholder"
                            label="Title"
                            placeholder="Title"                            
                            className={classes.textField}
                            required={true}
                            margin="normal"
                            value={this.state.n_title}
                            onChange={this.handleTitleChange}
                        />  
                    </Typography>
                    <Typography component="div" align='left'>
                    <TextField
                            id="standard-textarea"
                            label="Note-Description"
                            placeholder="Description"
                            multiline
                            className={classes.textField}
                            margin="normal"
                            value={this.state.n_description} onChange={this.handleDescChange}
                        />                        
                    </Typography>
                    <Button variant="contained" color="primary" type="submit">Save</Button>
                </form>
              </Paper>
              </div>
          );
     
    }
}

export default withStyles(styles)(NoteTaker);
