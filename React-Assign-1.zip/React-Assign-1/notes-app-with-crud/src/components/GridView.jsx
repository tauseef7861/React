import React from 'react';
import Note from './Note';
import PropTypes from 'prop-types';
import GridList from '@material-ui/core/GridList';
import GridListTile from '@material-ui/core/GridListTile';
import { withStyles } from '@material-ui/core/styles';



const styles = theme => ({
    root: {
        display: 'flex',
       justifyContent: 'space-around',
        overflow: 'hidden',
        flexwrap:'wrap',
        
    },
    gridList: {
        width: 500,
        height: 'auto',
       
    },
    icon: {
        color: 'rgba(255, 255, 255, 0.54)',
    },
});


class GridView extends React.Component {    


    render() {
        const { classes } = this.props;
        return (
            <div className={classes.root}>
                <GridList className={classes.gridList} cols={6}>
                {this.props.notes.map(note => (
                    <GridListTile key={note.id} cols={2}>
                        <Note key={note.id} 
                              id={note.id} 
                              title={note.title} 
                              content={note.description} 
                              handleRemove={this.props.handleRemove}                                   
                              handleUpdateNote={this.props.handleUpdateNote}
                              />
                    </GridListTile>
                ))}
            </GridList>
            </div>
        );
    }
}

GridView.propTypes = {
    classes: PropTypes.object.isRequired,
};

export default withStyles(styles)(GridView);  