import React from 'react';

import Button from '@material-ui/core/Button';
import TextField from '@material-ui/core/TextField';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogTitle from '@material-ui/core/DialogTitle';

class EditNote extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            open: true,
            title: this.props.title,
            description: this.props.description,
        }        
        this.handleClose = this.handleClose.bind(this);
        this.handleNoteTitleChanges=this.handleNoteTitleChanges.bind(this);
        this.handleNoteDescriptionChanges=this.handleNoteDescriptionChanges.bind(this);
        this.handleUpdateNote=this.handleUpdateNote.bind(this);
    }

    handleClose() {
        this.setState({ 
            open: false           
        });
        this.props.handleClickCancel(this.state.open);        
    }

    handleNoteTitleChanges(e){
        this.setState({ title: e.target.value });
    }

    handleNoteDescriptionChanges(e){    
        this.setState({ description: e.target.value });
    }

    handleUpdateNote() {
       const updatedNote = {
            id: this.props.id,
            title: this.state.title,
            description: this.state.description,
        }
        this.props.handleUpdateNote(updatedNote);
        this.handleClose();
    }

    render() {
        return (
            <React.Fragment>            
            <Dialog open={this.state.open} onClose={this.handleClose} aria-labelledby="form-dialog-title">
                <DialogTitle id="form-dialog-title">Update Note</DialogTitle>
                <DialogContent>
                    <TextField
                            autoFocus
                            margin="dense"
                            id="note title"
                            label="Note Title"
                            type="text"
                            fullWidth
                            onChange={this.handleNoteTitleChanges}
                            value={this.state.title}
                        />
                        <TextField
                            margin="dense"
                            id="note description"
                            label="Note Description"
                            type="text"
                            onChange={this.handleNoteDescriptionChanges}
                            value={this.state.description}
                            fullWidth
                        />
                </DialogContent>
                <DialogActions>
                    <Button onClick={this.handleClose} color="primary">
                        Cancel
                        </Button>
                    <Button onClick={this.handleUpdateNote} color="primary">
                        Update
                        </Button>
                </DialogActions>
            </Dialog>
            </React.Fragment>
        );
    }
}

export default EditNote;