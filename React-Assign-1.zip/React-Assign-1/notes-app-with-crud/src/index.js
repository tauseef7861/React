import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import NotesApp from './components/NotesApp';

ReactDOM.render(<NotesApp />, document.getElementById('root'));

